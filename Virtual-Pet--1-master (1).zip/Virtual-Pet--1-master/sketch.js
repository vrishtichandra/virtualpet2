//Create variables here

function preload()
{
	//load images here
}

function setup() {
	createCanvas(800, 700);
  
}


function draw() {  

  drawSprites();
  //add styles here

}



